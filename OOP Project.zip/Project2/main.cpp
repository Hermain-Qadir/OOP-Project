#include "MyForm.h"
#include "Code.h"
using namespace System; 
using namespace System::Windows::Forms; 
int main()
{


    Windows::Forms::Application::EnableVisualStyles();
    Windows::Forms::Application::Run(gcnew Project2::MyForm());

}
int Item::bill; 